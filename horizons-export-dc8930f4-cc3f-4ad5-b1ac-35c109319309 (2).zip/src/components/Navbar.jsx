
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Building, Menu, X, Search, UserCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { to: '/', text: 'Home' },
    { to: '/buy', text: 'Buy' },
    { to: '/rent', text: 'Rent' },
    { to: '/commercial', text: 'Commercial' },
  ];

  const mobileMenuVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0, transition: { staggerChildren: 0.1 } },
    exit: { opacity: 0, y: -20 }
  };

  const mobileLinkVariants = {
    hidden: { opacity: 0, y: -10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <nav className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-800 text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center space-x-2 text-2xl font-bold hover:opacity-80 transition-opacity">
            <Building size={32} />
            <span>301 Real Estate</span>
          </Link>

          <div className="hidden md:flex items-center space-x-2">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-md text-sm font-medium transition-colors hover:bg-white/20 ${
                    isActive ? 'bg-white/30' : ''
                  }`
                }
              >
                {link.text}
              </NavLink>
            ))}
          </div>
          
          <div className="hidden md:flex items-center space-x-3">
            <Button variant="outline" size="sm" className="text-white border-white hover:bg-white hover:text-primary" asChild>
              <Link to="/dashboard">Agent Dashboard</Link>
            </Button>
            <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white">
              <UserCircle className="mr-2 h-4 w-4" /> Login
            </Button>
          </div>

          <div className="md:hidden flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-white hover:bg-white/20"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            variants={mobileMenuVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="md:hidden bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-800 absolute w-full shadow-xl pb-4"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navLinks.map((link) => (
                <motion.div key={link.to} variants={mobileLinkVariants}>
                  <NavLink
                    to={link.to}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={({ isActive }) =>
                      `block px-3 py-2 rounded-md text-base font-medium transition-colors hover:bg-white/20 ${
                        isActive ? 'bg-white/30' : ''
                      }`
                    }
                  >
                    {link.text}
                  </NavLink>
                </motion.div>
              ))}
            </div>
            <motion.div variants={mobileLinkVariants} className="px-4 pt-2 pb-4 border-t border-white/20">
              <Button variant="outline" className="w-full mb-2 text-white border-white hover:bg-white hover:text-primary" asChild>
                <Link to="/dashboard" onClick={() => setIsMobileMenuOpen(false)}>Agent Dashboard</Link>
              </Button>
              <Button variant="secondary" className="w-full bg-white/20 hover:bg-white/30 text-white">
                <UserCircle className="mr-2 h-4 w-4" /> Login
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
  