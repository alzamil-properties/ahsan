
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

export const PropertyDescription = ({ description }) => {
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Description</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-slate-700 leading-relaxed whitespace-pre-line">
          {description || 'No description available.'}
        </p>
      </CardContent>
    </Card>
  );
};
  