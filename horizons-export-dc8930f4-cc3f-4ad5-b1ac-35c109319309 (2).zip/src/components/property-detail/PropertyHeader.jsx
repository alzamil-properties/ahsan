
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

export const PropertyHeader = ({ property, formatPrice }) => {
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start">
          <div>
            <CardTitle className="text-3xl font-bold text-primary mb-1">{property.title}</CardTitle>
            <CardDescription className="text-lg text-slate-600 flex items-center">
              <MapPin size={20} className="mr-2 flex-shrink-0" /> {property.location}
            </CardDescription>
          </div>
          <div className="mt-4 md:mt-0 text-left md:text-right">
            <p className="text-3xl font-bold text-slate-800">{formatPrice(property.price, property.currency, property.leaseType)}</p>
            {property.leaseType && <p className="text-sm text-slate-500">{property.leaseType}</p>}
            <p className="text-xs text-slate-400 mt-1">Ref ID: {property.referenceId || 'N/A'}</p>
          </div>
        </div>
      </CardHeader>
    </Card>
  );
};
  