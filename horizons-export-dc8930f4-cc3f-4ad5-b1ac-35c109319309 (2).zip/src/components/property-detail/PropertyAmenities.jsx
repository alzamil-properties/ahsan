
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { CheckCircle } from 'lucide-react';

export const PropertyAmenities = ({ amenities }) => {
  if (!amenities || amenities.length === 0) {
    return null;
  }

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Amenities</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-3 text-slate-700">
          {amenities.map((amenity, index) => (
            <li key={index} className="flex items-center">
              <CheckCircle size={18} className="mr-2 text-green-500 flex-shrink-0" />
              {amenity}
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};
  