
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Home } from 'lucide-react';

export const PropertyImageGallery = ({ images, title }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  if (!images || images.length === 0) {
    return (
      <Card className="overflow-hidden shadow-xl">
        <CardContent className="p-0">
          <div className="w-full h-[300px] md:h-[500px] bg-slate-200 flex items-center justify-center">
            <Home className="h-24 w-24 text-slate-400" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const handleNextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const handlePrevImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  return (
    <Card className="overflow-hidden shadow-xl">
      <CardContent className="p-0 relative">
        <div className="relative w-full h-[300px] md:h-[500px] bg-slate-200">
          <img  
            class="w-full h-full object-cover" 
            alt={`${title} - Image ${currentImageIndex + 1}`}
           src="https://images.unsplash.com/photo-1592177183170-a4256e44e072" />
          {images.length > 1 && (
            <>
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full"
                onClick={handlePrevImage}
              >
                <ChevronLeft />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full"
                onClick={handleNextImage}
              >
                <ChevronRight />
              </Button>
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white text-xs px-2 py-1 rounded-md">
                {currentImageIndex + 1} / {images.length}
              </div>
            </>
          )}
        </div>
        {images.length > 1 && (
          <div className="p-2 bg-slate-100">
            <div className="flex space-x-2 overflow-x-auto">
              {images.map((img, index) => (
                <button 
                  key={index} 
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-20 h-16 rounded-md overflow-hidden border-2 transition-all ${currentImageIndex === index ? 'border-primary scale-105' : 'border-transparent hover:border-primary/50'}`}
                >
                  <img  class="w-full h-full object-cover" alt={`Thumbnail ${index + 1}`} src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                </button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
  