
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, ExternalLink } from 'lucide-react';

export const PropertyLocationMap = ({ location }) => {
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Location</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-slate-700 mb-4 flex items-center">
          <MapPin size={18} className="mr-2 text-primary" /> {location}
        </p>
        <div className="aspect-video bg-slate-200 rounded-md flex items-center justify-center">
          <p className="text-slate-500">Map View (Coming Soon)</p>
        </div>
        <Button variant="outline" className="mt-4 w-full md:w-auto" onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`, '_blank')}>
          <ExternalLink size={16} className="mr-2" /> Open in Google Maps
        </Button>
      </CardContent>
    </Card>
  );
};
  