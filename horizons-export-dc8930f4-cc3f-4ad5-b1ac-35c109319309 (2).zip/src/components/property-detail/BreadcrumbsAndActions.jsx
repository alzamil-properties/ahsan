
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Share2, Heart, Printer } from 'lucide-react';

export const BreadcrumbsAndActions = ({ property }) => {
  return (
    <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
      <div className="text-sm text-slate-500 mb-2 md:mb-0">
        <Link to="/" className="hover:text-primary">Home</Link> &gt; 
        <Link to={`/${property.category}`} className="hover:text-primary capitalize"> {property.category}</Link> &gt; 
        <span className="font-medium text-slate-700"> {property.title}</span>
      </div>
      <div className="flex space-x-2">
        <Button variant="outline" size="sm" onClick={() => navigator.share ? navigator.share({ title: property.title, text: `Check out this property: ${property.title}`, url: window.location.href }) : alert('Share not supported on this browser.')}>
          <Share2 className="mr-2 h-4 w-4" /> Share
        </Button>
        <Button variant="outline" size="sm" onClick={() => alert('Added to Favourites (Feature coming soon!)')}>
          <Heart className="mr-2 h-4 w-4" /> Favourite
        </Button>
        <Button variant="outline" size="sm" onClick={() => window.print()}>
          <Printer className="mr-2 h-4 w-4" /> Print
        </Button>
      </div>
    </div>
  );
};
  