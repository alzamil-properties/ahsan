
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Home, Bed, Bath, Maximize, Tag, CalendarDays, Briefcase } from 'lucide-react';

export const PropertyKeyDetails = ({ property }) => {
  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Key Details</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-x-4 gap-y-6 text-slate-700">
          <div className="flex items-center space-x-2">
            {property.category === 'commercial' ? <Briefcase size={24} className="text-primary" /> : <Home size={24} className="text-primary" />}
            <div>
              <p className="text-xs text-slate-500">Type</p>
              <p className="font-medium">{property.type}</p>
            </div>
          </div>
          {property.beds && (
            <div className="flex items-center space-x-2">
              <Bed size={24} className="text-primary" />
              <div>
                <p className="text-xs text-slate-500">Bedrooms</p>
                <p className="font-medium">{property.beds}</p>
              </div>
            </div>
          )}
          {property.baths && (
            <div className="flex items-center space-x-2">
              <Bath size={24} className="text-primary" />
              <div>
                <p className="text-xs text-slate-500">Bathrooms</p>
                <p className="font-medium">{property.baths}</p>
              </div>
            </div>
          )}
          <div className="flex items-center space-x-2">
            <Maximize size={24} className="text-primary" />
            <div>
              <p className="text-xs text-slate-500">Area</p>
              <p className="font-medium">{property.area} m²</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Tag size={24} className="text-primary" />
            <div>
              <p className="text-xs text-slate-500">Status</p>
              <p className="font-medium capitalize">{property.category === 'rent' || property.leaseType === 'For Lease' ? 'For Rent' : 'For Sale'}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <CalendarDays size={24} className="text-primary" />
            <div>
              <p className="text-xs text-slate-500">Listed On</p>
              <p className="font-medium">{new Date().toLocaleDateString('en-GB')}</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
  