
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { Phone, Mail, MessageSquare, CheckCircle } from 'lucide-react';

export const PropertyAgentCard = ({ agent, propertyTitle, propertyRefId, propertyId }) => {
  const { toast } = useToast();

  const handleEnquirySubmit = (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const name = formData.get('name');
    const email = formData.get('email');
    const phone = formData.get('phone');
    const message = formData.get('message');

    if (!name || !email || !message) {
      toast({
        title: "Error",
        description: "Please fill in all required fields (Name, Email, Message).",
        variant: "destructive",
      });
      return;
    }
    
    console.log("Enquiry submitted:", { name, email, phone, message, propertyId });
    toast({
      title: "Enquiry Sent!",
      description: "Your message has been sent to the agent. They will contact you shortly.",
      variant: "success",
      action: <CheckCircle className="text-green-500" />,
    });
    event.target.reset();
    // Consider closing dialog here if state is managed for Dialog open prop
  };

  return (
    <Card className="shadow-xl sticky top-24">
      <CardHeader className="bg-gradient-to-br from-primary to-blue-700 text-primary-foreground p-6 rounded-t-lg">
        <div className="flex items-center space-x-4">
          <div className="bg-white/20 p-1 rounded-full">
            <img  class="w-16 h-16 rounded-full object-cover border-2 border-white" alt={agent?.name || 'Agent'} src="https://images.unsplash.com/photo-1672870153272-1ce7b03bf04b" />
          </div>
          <div>
            <CardTitle className="text-xl font-bold">{agent?.name || '301 Real Estate Agent'}</CardTitle>
            <CardDescription className="text-sm text-blue-100">Your dedicated consultant</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        {agent?.phone && (
          <a href={`tel:${agent.phone}`} className="flex items-center text-slate-700 hover:text-primary transition-colors group">
            <Phone size={20} className="mr-3 text-primary/80 group-hover:text-primary" />
            <span>{agent.phone}</span>
          </a>
        )}
        {agent?.email && (
          <a href={`mailto:${agent.email}`} className="flex items-center text-slate-700 hover:text-primary transition-colors group">
            <Mail size={20} className="mr-3 text-primary/80 group-hover:text-primary" />
            <span>{agent.email}</span>
          </a>
        )}
        <Separator />
        
        <Dialog>
          <DialogTrigger asChild>
            <Button size="lg" className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white">
              <MessageSquare size={20} className="mr-2" /> Send Enquiry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[480px]">
            <DialogHeader>
              <DialogTitle className="text-2xl">Contact Agent about "{propertyTitle}"</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleEnquirySubmit} className="space-y-4 pt-4">
              <div>
                <Label htmlFor="name" className="text-sm font-medium">Full Name</Label>
                <Input id="name" name="name" placeholder="Your Name" className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                <Input id="email" name="email" type="email" placeholder="your@email.com" className="mt-1" required/>
              </div>
              <div>
                <Label htmlFor="phone" className="text-sm font-medium">Phone Number (Optional)</Label>
                <Input id="phone" name="phone" type="tel" placeholder="+973 XXXX XXXX" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="message" className="text-sm font-medium">Message</Label>
                <Textarea 
                  id="message" 
                  name="message"
                  placeholder={`I am interested in "${propertyTitle}" (Ref: ${propertyRefId || 'N/A'}). Please provide more details.`} 
                  rows={4} 
                  className="mt-1"
                  defaultValue={`I am interested in "${propertyTitle}" (Ref: ${propertyRefId || 'N/A'}). Please provide more details.`}
                  required
                />
              </div>
              <p className="text-xs text-slate-500">
                By submitting this form, you agree to our terms and conditions.
              </p>
              <Button type="submit" size="lg" className="w-full">Send Message</Button>
            </form>
          </DialogContent>
        </Dialog>

        {agent?.phone && (
           <Button variant="outline" className="w-full" asChild>
             <a href={`tel:${agent.phone}`}>
                <Phone size={20} className="mr-2" /> Call Agent
             </a>
           </Button>
        )}
      </CardContent>
    </Card>
  );
};
  