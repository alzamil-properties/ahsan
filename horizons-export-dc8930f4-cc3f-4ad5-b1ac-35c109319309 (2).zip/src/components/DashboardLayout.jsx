
import React from 'react';
import { Outlet } from 'react-router-dom';
import DashboardSidebar from '@/components/DashboardSidebar';
import { motion } from 'framer-motion';

const DashboardLayout = () => {
  return (
    <div className="flex h-screen bg-slate-100">
      <DashboardSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-sm p-4">
          {/* You can add a dashboard-specific header here if needed */}
          <h1 className="text-xl font-semibold text-slate-700">Agent Dashboard</h1>
        </header>
        <motion.main
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 p-6"
        >
          <Outlet />
        </motion.main>
      </div>
    </div>
  );
};

export default DashboardLayout;
  