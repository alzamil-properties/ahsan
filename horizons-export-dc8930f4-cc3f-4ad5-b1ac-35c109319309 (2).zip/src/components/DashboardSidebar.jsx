
import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { Building, LayoutDashboard, PlusCircle, ListChecks, Users, BarChart3, LogOut, Settings } from 'lucide-react';

const sidebarNavItems = [
  { to: '/dashboard', icon: LayoutDashboard, text: 'Board' },
  {
    text: 'Properties',
    icon: Building,
    subItems: [
      { to: '/dashboard/properties/all', text: 'All' },
      { to: '/dashboard/properties/published', text: 'Published' },
      { to: '/dashboard/properties/pending', text: 'Pending' },
      { to: '/dashboard/add-property', text: 'Create a Listing', icon: PlusCircle },
    ],
  },
  { to: '/dashboard/enquiries', icon: ListChecks, text: 'Enquiries' },
  { to: '/dashboard/agents', icon: Users, text: 'Agents' },
  { to: '/dashboard/insights', icon: BarChart3, text: 'Insights' },
];

const DashboardSidebar = () => {
  return (
    <div className="w-64 bg-slate-800 text-slate-200 flex flex-col h-screen">
      <div className="p-6 border-b border-slate-700">
        <Link to="/" className="flex items-center space-x-2 text-2xl font-bold text-white hover:opacity-80 transition-opacity">
          <Building size={30} />
          <span>301 Real Estate</span>
        </Link>
      </div>
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {sidebarNavItems.map((item, index) => (
          <div key={index}>
            {item.subItems ? (
              <div>
                <div className="flex items-center px-3 py-2.5 text-sm font-medium text-slate-400">
                  {item.icon && <item.icon className="mr-3 h-5 w-5" />}
                  {item.text}
                </div>
                <div className="ml-4 space-y-1">
                  {item.subItems.map((subItem) => (
                    <NavLink
                      key={subItem.to}
                      to={subItem.to}
                      className={({ isActive }) =>
                        `flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors hover:bg-slate-700 hover:text-white ${
                          isActive ? 'bg-slate-700 text-white' : 'text-slate-300'
                        }`
                      }
                    >
                      {subItem.icon && <subItem.icon className="mr-3 h-5 w-5" />}
                      {subItem.text}
                    </NavLink>
                  ))}
                </div>
              </div>
            ) : (
              <NavLink
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors hover:bg-slate-700 hover:text-white ${
                    isActive ? 'bg-slate-700 text-white' : 'text-slate-300'
                  }`
                }
              >
                {item.icon && <item.icon className="mr-3 h-5 w-5" />}
                {item.text}
              </NavLink>
            )}
          </div>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-700 space-y-2">
        <NavLink
          to="/dashboard/settings"
          className={({ isActive }) =>
            `flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors hover:bg-slate-700 hover:text-white ${
              isActive ? 'bg-slate-700 text-white' : 'text-slate-300'
            }`
          }
        >
          <Settings className="mr-3 h-5 w-5" />
          Settings
        </NavLink>
        <button
          onClick={() => { /* Implement logout logic */ }}
          className="flex items-center w-full px-3 py-2.5 rounded-md text-sm font-medium text-slate-300 transition-colors hover:bg-slate-700 hover:text-white"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default DashboardSidebar;
  