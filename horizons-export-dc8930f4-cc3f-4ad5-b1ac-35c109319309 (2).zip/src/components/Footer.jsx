
import React from 'react';
import { Link } from 'react-router-dom';
import { Building, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-800 text-slate-300 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <Link to="/" className="flex items-center space-x-2 text-xl font-bold text-white mb-4 hover:opacity-80 transition-opacity">
              <Building size={28} />
              <span>301 Real Estate</span>
            </Link>
            <p className="text-sm">
              Your trusted partner in finding the perfect property. Explore listings for sale, rent, and commercial spaces.
            </p>
          </div>

          <div>
            <h5 className="text-lg font-semibold text-white mb-4">Quick Links</h5>
            <ul className="space-y-2">
              <li><Link to="/buy" className="hover:text-white transition-colors">Buy Properties</Link></li>
              <li><Link to="/rent" className="hover:text-white transition-colors">Rent Properties</Link></li>
              <li><Link to="/commercial" className="hover:text-white transition-colors">Commercial</Link></li>
              <li><Link to="/dashboard" className="hover:text-white transition-colors">Agent Dashboard</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="text-lg font-semibold text-white mb-4">Contact Us</h5>
            <ul className="space-y-2 text-sm">
              <li>123 Real Estate Ave, City, Country</li>
              <li>Email: info@301realestate.com</li>
              <li>Phone: +1 (234) 567-8900</li>
            </ul>
          </div>

          <div>
            <h5 className="text-lg font-semibold text-white mb-4">Follow Us</h5>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-300 hover:text-white transition-colors"><Facebook size={20} /></a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors"><Twitter size={20} /></a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors"><Instagram size={20} /></a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors"><Linkedin size={20} /></a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-700 pt-8 text-center text-sm">
          <p>&copy; {currentYear} 301 Real Estate. All rights reserved. </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
  