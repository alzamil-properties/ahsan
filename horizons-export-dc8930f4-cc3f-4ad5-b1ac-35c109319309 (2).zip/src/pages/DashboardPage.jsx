
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Search, PlusCircle, MoreHorizontal, Edit, Trash2, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const initialDashboardProperties = [
  { id: 'P001', title: 'Apartment With Ocean View', type: 'Apartment', status: 'Published', price: 1350000, address: '9701 W Broadview Dr, Bay Harbor Islands, FL 31175', expiration: '2025-06-09', image: 'apartment-ocean-view-thumbnail' },
  { id: 'P002', title: 'Comfortable Villa', type: 'Villa', status: 'Published', price: 350000, address: '123 Lake Rd, Miami, FL 33101', expiration: '2025-08-15', image: 'comfortable-villa-thumbnail' },
  { id: 'P003', title: 'Big Apartment For Rent', type: 'Apartment', status: 'Pending', price: 990000, address: '456 Downtown Ave, Orlando, FL 32801', expiration: '2025-07-20', image: 'big-apartment-rent-thumbnail' },
  { id: 'P004', title: 'Ocean View Apartment', type: 'Apartment', status: 'Pending', price: 350000, address: '789 Beach Blvd, Fort Lauderdale, FL 33301', expiration: '2025-09-01', image: 'ocean-view-apartment-thumbnail-alt' },
  { id: 'P005', title: 'Penthouse Apartment', type: 'Penthouse', status: 'Draft', price: 2750000, address: '101 Sky High Rd, Miami Beach, FL 33139', expiration: '2025-10-10', image: 'penthouse-apartment-thumbnail' },
];

const DashboardPage = () => {
  const [properties, setProperties] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const storedProperties = JSON.parse(localStorage.getItem('dashboard_properties')) || initialDashboardProperties;
    setProperties(storedProperties);
    if (!localStorage.getItem('dashboard_properties')) {
      localStorage.setItem('dashboard_properties', JSON.stringify(initialDashboardProperties));
    }
  }, []);

  const filteredProperties = properties.filter(property =>
    property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    property.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    property.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (propertyId) => {
    if (window.confirm('Are you sure you want to delete this property?')) {
      const updatedProperties = properties.filter(p => p.id !== propertyId);
      setProperties(updatedProperties);
      localStorage.setItem('dashboard_properties', JSON.stringify(updatedProperties));
      toast({
        title: "Property Deleted",
        description: `Property ID ${propertyId} has been successfully deleted.`,
        variant: "destructive",
      });
    }
  };
  
  const getStatusVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'published': return 'published';
      case 'pending': return 'pending';
      case 'expired': return 'expired';
      case 'draft': return 'draft';
      case 'on hold': return 'onHold';
      default: return 'default';
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(price);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      className="space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div className="flex flex-col sm:flex-row justify-between items-center gap-4" variants={itemVariants}>
        <h2 className="text-3xl font-semibold text-slate-800">My Properties</h2>
        <Button asChild className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-md hover:shadow-lg transition-shadow">
          <Link to="/dashboard/add-property">
            <PlusCircle className="mr-2 h-5 w-5" /> Create a Listing
          </Link>
        </Button>
      </motion.div>

      <motion.div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-white rounded-lg shadow" variants={itemVariants}>
        <div className="relative flex-grow w-full sm:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
          <Input
            placeholder="Search by Title, Address, or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 w-full"
          />
        </div>
        <Button className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-white">
          Search
        </Button>
        <span className="text-sm text-slate-500 hidden sm:block">Sort by: Default Order</span>
      </motion.div>

      <motion.div className="bg-white rounded-lg shadow overflow-x-auto" variants={itemVariants}>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[80px]">Thumbnail</TableHead>
              <TableHead>Address</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Price</TableHead>
              <TableHead className="text-center">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProperties.map((property) => (
              <TableRow key={property.id} className="hover:bg-slate-50 transition-colors">
                <TableCell>
                  <img  class="h-12 w-16 object-cover rounded-md border" alt={property.title} src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
                </TableCell>
                <TableCell>
                  <div className="font-medium text-slate-700">{property.title}</div>
                  <div className="text-xs text-slate-500">{property.address}</div>
                  <div className="text-xs text-slate-400">Expiration: {new Date(property.expiration).toLocaleDateString()}</div>
                </TableCell>
                <TableCell className="text-slate-600">{property.type}</TableCell>
                <TableCell>
                  <Badge variant={getStatusVariant(property.status)}>{property.status}</Badge>
                </TableCell>
                <TableCell className="text-right font-semibold text-slate-700">{formatPrice(property.price)}</TableCell>
                <TableCell className="text-center">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0 data-[state=open]:bg-slate-100">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-[160px]">
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" /> View
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDelete(property.id)} className="text-red-600 focus:text-red-600 focus:bg-red-50">
                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {filteredProperties.length === 0 && (
          <div className="text-center p-8 text-slate-500">
            No properties found matching your search.
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default DashboardPage;
  