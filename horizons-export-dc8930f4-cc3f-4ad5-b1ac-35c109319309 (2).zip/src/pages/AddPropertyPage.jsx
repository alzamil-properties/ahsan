
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { UploadCloud, DollarSign, MapPin, Bed, Bath, Maximize, Building, CalendarDays, Save } from 'lucide-react';

const AddPropertyPage = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    propertyType: '', // e.g., Apartment, House, Commercial
    listingType: 'For Sale', // For Sale, For Rent
    bedrooms: '',
    bathrooms: '',
    area: '', // sqft
    lotSize: '', // if applicable
    yearBuilt: '',
    amenities: [],
    images: [],
    status: 'Draft', // Draft, Pending, Published
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (amenity) => {
    setFormData(prev => {
      const newAmenities = prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity];
      return { ...prev, amenities: newAmenities };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic validation
    if (!formData.title || !formData.price || !formData.address || !formData.propertyType) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields (Title, Price, Address, Property Type).",
        variant: "destructive",
      });
      return;
    }

    const newProperty = {
      id: `P${Date.now().toString().slice(-4)}`, // Simple unique ID
      ...formData,
      price: parseFloat(formData.price) || 0,
      expiration: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Expires in 30 days
      image: formData.images.length > 0 ? formData.images[0].name : 'default-property-thumbnail', // Placeholder
    };
    
    const existingProperties = JSON.parse(localStorage.getItem('dashboard_properties')) || [];
    localStorage.setItem('dashboard_properties', JSON.stringify([...existingProperties, newProperty]));

    toast({
      title: "Property Added!",
      description: `${formData.title} has been successfully added to your listings.`,
    });
    navigate('/dashboard'); 
  };

  const amenitiesList = ['Swimming Pool', 'Gym', 'Parking', 'Garden', 'Balcony', 'Air Conditioning', 'Security System', 'Pet Friendly'];

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
  };

  return (
    <motion.div 
      initial="hidden"
      animate="visible"
      variants={{ visible: { transition: { staggerChildren: 0.1 }}}}
      className="max-w-4xl mx-auto"
    >
      <motion.div variants={itemVariants}>
        <CardHeader className="px-0">
          <CardTitle className="text-3xl font-bold text-slate-800">Create New Listing</CardTitle>
          <CardDescription>Fill in the details below to add a new property to the market.</CardDescription>
        </CardHeader>
      </motion.div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Label htmlFor="title">Property Title</Label>
                <Input id="title" name="title" value={formData.title} onChange={handleInputChange} placeholder="e.g., Spacious 3-Bedroom Family Home" required />
              </div>
              <div>
                <Label htmlFor="listingType">Listing Type</Label>
                <Select name="listingType" value={formData.listingType} onValueChange={(value) => handleSelectChange('listingType', value)}>
                  <SelectTrigger><SelectValue placeholder="Select listing type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="For Sale">For Sale</SelectItem>
                    <SelectItem value="For Rent">For Rent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="propertyType">Property Type</Label>
                <Select name="propertyType" value={formData.propertyType} onValueChange={(value) => handleSelectChange('propertyType', value)} required>
                  <SelectTrigger><SelectValue placeholder="Select property type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="House">House</SelectItem>
                    <SelectItem value="Apartment">Apartment</SelectItem>
                    <SelectItem value="Condo">Condo</SelectItem>
                    <SelectItem value="Townhouse">Townhouse</SelectItem>
                    <SelectItem value="Villa">Villa</SelectItem>
                    <SelectItem value="Office">Office (Commercial)</SelectItem>
                    <SelectItem value="Retail">Retail (Commercial)</SelectItem>
                    <SelectItem value="Warehouse">Warehouse (Commercial)</SelectItem>
                    <SelectItem value="Land">Land</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} placeholder="Detailed description of the property..." rows={4} />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Location</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Label htmlFor="address">Street Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="address" name="address" value={formData.address} onChange={handleInputChange} placeholder="123 Main St" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="city">City</Label>
                <Input id="city" name="city" value={formData.city} onChange={handleInputChange} placeholder="Anytown" />
              </div>
              <div>
                <Label htmlFor="state">State/Province</Label>
                <Input id="state" name="state" value={formData.state} onChange={handleInputChange} placeholder="CA" />
              </div>
              <div>
                <Label htmlFor="zipCode">Zip/Postal Code</Label>
                <Input id="zipCode" name="zipCode" value={formData.zipCode} onChange={handleInputChange} placeholder="90210" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Property Details</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="price">Price (USD)</Label>
                 <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="price" name="price" type="number" value={formData.price} onChange={handleInputChange} placeholder="e.g., 500000" className="pl-10" required />
                </div>
              </div>
              <div>
                <Label htmlFor="bedrooms">Bedrooms</Label>
                <div className="relative">
                  <Bed className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="bedrooms" name="bedrooms" type="number" value={formData.bedrooms} onChange={handleInputChange} placeholder="e.g., 3" className="pl-10" />
                </div>
              </div>
              <div>
                <Label htmlFor="bathrooms">Bathrooms</Label>
                <div className="relative">
                  <Bath className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="bathrooms" name="bathrooms" type="number" step="0.5" value={formData.bathrooms} onChange={handleInputChange} placeholder="e.g., 2.5" className="pl-10" />
                </div>
              </div>
              <div>
                <Label htmlFor="area">Area (sqft)</Label>
                <div className="relative">
                  <Maximize className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="area" name="area" type="number" value={formData.area} onChange={handleInputChange} placeholder="e.g., 1800" className="pl-10" />
                </div>
              </div>
              <div>
                <Label htmlFor="lotSize">Lot Size (sqft)</Label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="lotSize" name="lotSize" type="number" value={formData.lotSize} onChange={handleInputChange} placeholder="e.g., 5000 (if applicable)" className="pl-10" />
                </div>
              </div>
              <div>
                <Label htmlFor="yearBuilt">Year Built</Label>
                <div className="relative">
                  <CalendarDays className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="yearBuilt" name="yearBuilt" type="number" value={formData.yearBuilt} onChange={handleInputChange} placeholder="e.g., 1995" className="pl-10" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Amenities</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {amenitiesList.map(amenity => (
                <div key={amenity} className="flex items-center space-x-2">
                  <Checkbox
                    id={`amenity-${amenity.toLowerCase().replace(' ', '-')}`}
                    checked={formData.amenities.includes(amenity)}
                    onCheckedChange={() => handleCheckboxChange(amenity)}
                  />
                  <Label htmlFor={`amenity-${amenity.toLowerCase().replace(' ', '-')}`} className="font-normal">{amenity}</Label>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Property Images</CardTitle>
              <CardDescription>Upload high-quality images of the property.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors">
                <UploadCloud className="mx-auto h-12 w-12 text-slate-400 mb-2" />
                <p className="text-sm text-slate-500">Drag & drop images here, or click to select files</p>
                <Input type="file" multiple className="opacity-0 absolute inset-0 w-full h-full cursor-pointer" onChange={(e) => setFormData(prev => ({...prev, images: Array.from(e.target.files)}))} />
              </div>
              {formData.images.length > 0 && (
                <div className="mt-4 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {formData.images.map((file, index) => (
                    <div key={index} className="relative">
                      <img  class="w-full h-24 object-cover rounded" alt={`Uploaded property image ${index + 1}`} src="https://images.unsplash.com/photo-1687031317737-53bd68f49e9f" />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Listing Status</CardTitle>
            </CardHeader>
            <CardContent>
              <Select name="status" value={formData.status} onValueChange={(value) => handleSelectChange('status', value)}>
                <SelectTrigger className="w-full md:w-1/2"><SelectValue placeholder="Select status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Draft">Draft (Save for later)</SelectItem>
                  <SelectItem value="Pending">Pending Review</SelectItem>
                  <SelectItem value="Published">Published (Live on site)</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="flex justify-end space-x-4 pt-4">
          <Button type="button" variant="outline" onClick={() => navigate('/dashboard')}>
            Cancel
          </Button>
          <Button type="submit" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-md hover:shadow-lg transition-all transform hover:scale-105">
            <Save className="mr-2 h-5 w-5" /> Save Listing
          </Button>
        </motion.div>
      </form>
    </motion.div>
  );
};

export default AddPropertyPage;
  