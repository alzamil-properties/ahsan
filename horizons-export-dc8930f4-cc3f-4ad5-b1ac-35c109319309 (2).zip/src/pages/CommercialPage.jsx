
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { MapPin, Maximize, Search, Briefcase, ArrowRight, Home } from 'lucide-react';
import { motion } from 'framer-motion';

const initialProperties = [
  { id: 12, title: 'Prime Office Space in Diplomatic Area', price: 3000, leaseType: 'For Lease', type: 'Office', area: 450, location: 'Diplomatic Area, Manama', image: 'prime-office-space-downtown-lobby', currency: 'BHD', category: 'commercial' },
  { id: 13, title: 'Retail Storefront in Seef Mall', price: 450000, leaseType: 'For Sale', type: 'Retail', area: 230, location: 'Seef District, Manama', image: 'retail-storefront-busy-street', currency: 'BHD', category: 'commercial' },
  { id: 14, title: 'Warehouse with Loading Docks Hidd', price: 2000, leaseType: 'For Lease', type: 'Warehouse', area: 900, location: 'Hidd Industrial Area, Muharraq', image: 'warehouse-exterior-loading-docks', currency: 'BHD', category: 'commercial' },
  { id: 15, title: 'Restaurant Space in Adliya', price: 350000, leaseType: 'For Sale', type: 'Restaurant', area: 320, location: 'Adliya, Manama', image: 'restaurant-space-outdoor-patio', currency: 'BHD', category: 'commercial' },
  { id: 16, title: 'Medical Clinic Building Janabiyah', price: 670000, leaseType: 'For Sale', type: 'Medical', area: 650, location: 'Janabiyah, Northern Governorate', image: 'modern-medical-clinic-exterior', currency: 'BHD', category: 'commercial' },
];

const CommercialPage = () => {
  const [properties, setProperties] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [propertyType, setPropertyType] = useState('all');
  const [priceRange, setPriceRange] = useState([0, 1000000]); 
  const [leaseType, setLeaseType] = useState('all');

  useEffect(() => {
    const storedProperties = JSON.parse(localStorage.getItem('properties_commercial')) || initialProperties;
    setProperties(storedProperties);
     if (!localStorage.getItem('properties_commercial')) {
      localStorage.setItem('properties_commercial', JSON.stringify(initialProperties));
    }
  }, []);

  const filteredProperties = properties.filter(property => {
    return (
      (property.title.toLowerCase().includes(searchTerm.toLowerCase()) || property.location.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (propertyType === 'all' || property.type.toLowerCase() === propertyType.toLowerCase()) &&
      (property.price >= priceRange[0] && property.price <= priceRange[1]) &&
      (leaseType === 'all' || property.leaseType.toLowerCase().replace(' ', '') === leaseType.toLowerCase())
    );
  });

  const formatPrice = (price, pLeaseType) => {
    const baseFormat = new Intl.NumberFormat('en-BH', { style: 'currency', currency: 'BHD', minimumFractionDigits: 0 }).format(price);
    return pLeaseType === 'For Lease' ? `${baseFormat}/mo` : baseFormat;
  };

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.div initial="hidden" animate="visible" variants={fadeIn}>
        <h1 className="text-4xl font-bold mb-8 text-center text-slate-800">Commercial Properties</h1>
      </motion.div>

      <motion.div 
        className="mb-10 p-6 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl shadow-lg border border-slate-200"
        initial="hidden" animate="visible" variants={{...fadeIn, visible: {...fadeIn.visible, transition: {...fadeIn.visible.transition, delay: 0.2}}}}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
              <Input 
                placeholder="Keyword, Location..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Property Type</label>
            <Select value={propertyType} onValueChange={setPropertyType}>
              <SelectTrigger>
                <SelectValue placeholder="Select Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="office">Office</SelectItem>
                <SelectItem value="retail">Retail</SelectItem>
                <SelectItem value="warehouse">Warehouse</SelectItem>
                <SelectItem value="restaurant">Restaurant</SelectItem>
                <SelectItem value="medical">Medical</SelectItem>
                <SelectItem value="industrial">Industrial</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Lease/Sale</label>
            <Select value={leaseType} onValueChange={setLeaseType}>
              <SelectTrigger>
                <SelectValue placeholder="Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="forlease">For Lease</SelectItem>
                <SelectItem value="forsale">For Sale</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Price / Monthly Rent: {formatPrice(priceRange[0], 'Any')} - {formatPrice(priceRange[1], 'Any')}
            </label>
            <Slider
              value={priceRange}
              min={0}
              max={1000000} 
              step={10000}
              onValueChange={setPriceRange}
              className="py-2"
            />
          </div>
          <Button className="lg:col-start-4 bg-primary hover:bg-primary/90 text-white">
            Apply Filters
          </Button>
        </div>
      </motion.div>

      {filteredProperties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProperties.map((property, index) => (
            <motion.div
              key={property.id}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={{
                hidden: { opacity: 0, y: 50 },
                visible: (i) => ({
                  opacity: 1,
                  y: 0,
                  transition: { delay: i * 0.1 + 0.4, duration: 0.5 }
                })
              }}
            >
              <Card className="overflow-hidden hover:shadow-2xl transition-shadow duration-300 h-full flex flex-col group">
                <div className="relative h-64">
                   <img  class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt={property.title} src="https://images.unsplash.com/photo-1685279053124-f47a436a9c1e" />
                  <div className="absolute top-3 left-3 bg-primary/80 backdrop-blur-sm text-white px-3 py-1.5 rounded-md text-xs font-semibold shadow-md">{property.leaseType}</div>
                </div>
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{property.title}</CardTitle>
                  <CardDescription className="flex items-center text-sm text-slate-500 pt-1">
                    <MapPin className="h-4 w-4 mr-1.5 flex-shrink-0" /> {property.location}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow space-y-3">
                  <div className="text-2xl font-bold text-primary flex items-center">
                    <Home className="h-6 w-6 mr-1.5" /> {formatPrice(property.price, property.leaseType)}
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-slate-600">
                    <span className="flex items-center"><Briefcase className="h-4 w-4 mr-1.5 text-primary/70" /> {property.type}</span>
                    <span className="flex items-center"><Maximize className="h-4 w-4 mr-1.5 text-primary/70" /> {property.area} m²</span>
                  </div>
                </CardContent>
                <div className="p-6 pt-0">
                  <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-white transition-colors" asChild>
                     <Link to={`/property/${property.id}?category=${property.category}`}>
                      View Details <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <motion.div 
          className="text-center py-12"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        >
          <Search className="h-16 w-16 mx-auto text-slate-400 mb-4" />
          <p className="text-xl text-slate-600">No commercial properties match your current filters.</p>
          <p className="text-slate-500">Try adjusting your search criteria.</p>
        </motion.div>
      )}
    </div>
  );
};

export default CommercialPage;
  