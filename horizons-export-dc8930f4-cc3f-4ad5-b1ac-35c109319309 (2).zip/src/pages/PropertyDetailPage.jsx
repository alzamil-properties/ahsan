
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { PropertyImageGallery } from '@/components/property-detail/PropertyImageGallery';
import { PropertyHeader } from '@/components/property-detail/PropertyHeader';
import { PropertyKeyDetails } from '@/components/property-detail/PropertyKeyDetails';
import { PropertyDescription } from '@/components/property-detail/PropertyDescription';
import { PropertyAmenities } from '@/components/property-detail/PropertyAmenities';
import { PropertyLocationMap } from '@/components/property-detail/PropertyLocationMap';
import { PropertyAgentCard } from '@/components/property-detail/PropertyAgentCard';
import { PropertyMortgageCalculator } from '@/components/property-detail/PropertyMortgageCalculator';
import { BreadcrumbsAndActions } from '@/components/property-detail/BreadcrumbsAndActions';

import { Home, AlertCircle } from 'lucide-react';

const initialBuyProperties = [
  { id: 1, title: 'Modern Downtown Apartment', price: 280000, type: 'Apartment', beds: 3, baths: 2, area: 170, location: 'Seef District, Manama', currency: 'BHD', category: 'buy', description: 'Stunning 3-bedroom apartment in the heart of Seef, offering breathtaking city views. Features include a modern kitchen, spacious living area, and access to premium building amenities like a pool and gym. Perfect for professionals or small families seeking a vibrant urban lifestyle.', amenities: ['Swimming Pool', 'Gym', 'Covered Parking', '24/7 Security', 'City Views'], agent: { name: 'Ali Khan', phone: '+973 3333 4444', email: 'ali.khan@301realestate.bh' }, images: ['modern-apartment-balcony-view', 'modern-apartment-living-room-bright', 'modern-kitchen-island-stools', 'modern-bedroom-large-window', 'luxury-bathroom-marble-double-sink'], referenceId: '301-B-001' },
  { id: 2, title: 'Suburban Family Villa', price: 170000, type: 'Villa', beds: 4, baths: 3, area: 230, location: 'Saar, Northern Governorate', currency: 'BHD', category: 'buy', description: 'Beautifully maintained 4-bedroom villa in a quiet Saar neighborhood. Boasts a private garden, maid\'s room, and ample parking. Ideal for families looking for space and tranquility. Close to schools and local amenities.', amenities: ['Private Garden', 'Maid\'s Room', 'Covered Parking', 'Pet Friendly', 'Quiet Neighborhood'], agent: { name: 'Fatima Ahmed', phone: '+973 3333 5555', email: 'fatima.ahmed@301realestate.bh' }, images: ['suburban-house-with-garden', 'spacious-living-room-villa', 'kitchen-villa-granite-counters', 'master-bedroom-villa-ensuite', 'garden-villa-patio-area'], referenceId: '301-B-002' },
  { id: 3, title: 'Luxury Penthouse Suite', price: 560000, type: 'Penthouse', beds: 5, baths: 4.5, area: 370, location: 'Bahrain Bay, Manama', currency: 'BHD', category: 'buy', description: 'Exclusive penthouse with panoramic views of Bahrain Bay. This luxurious property features high-end finishes, a private terrace, smart home technology, and access to 5-star hotel amenities. An unparalleled living experience.', amenities: ['Private Terrace', 'Panoramic Views', 'Smart Home System', 'Concierge Service', 'Valet Parking'], agent: { name: 'Yusuf Mansoor', phone: '+973 3333 6666', email: 'yusuf.mansoor@301realestate.bh' }, images: ['luxury-penthouse-interior-night', 'penthouse-living-area-view', 'gourmet-kitchen-penthouse', 'master-suite-penthouse-view', 'rooftop-terrace-penthouse-jacuzzi'], referenceId: '301-B-003' },
];
const initialRentProperties = [
   { id: 7, title: 'Chic Studio in Adliya', price: 700, type: 'Studio', beds: 1, baths: 1, area: 55, location: 'Adliya, Manama', currency: 'BHD', category: 'rent', description: 'Stylish and fully furnished studio apartment in the vibrant Adliya district. Perfect for singles or couples. Includes all utilities and internet. Close to popular restaurants and cafes.', amenities: ['Fully Furnished', 'Inclusive EWA', 'High-speed Internet', 'Shared Gym', 'Rooftop Pool'], agent: { name: 'Layla Hassan', phone: '+973 3333 7777', email: 'layla.hassan@301realestate.bh' }, images: ['chic-studio-apartment-interior', 'studio-kitchenette-compact', 'modern-bathroom-studio', 'studio-living-sleeping-area', 'rooftop-pool-city-view-apartment'], referenceId: '301-R-001' },
   { id: 8, title: 'Family Apartment with Balcony Seef', price: 1000, type: 'Apartment', beds: 3, baths: 2, area: 140, location: 'Seef District, Manama', currency: 'BHD', category: 'rent', description: 'Spacious 3-bedroom apartment in Seef, ideal for families. Features a large balcony, modern amenities, and allocated parking. Close to Seef Mall and major highways.', amenities: ['Balcony', 'Allocated Parking', 'Children\'s Play Area', '24/7 Maintenance', 'Close to Mall'], agent: { name: 'Omar Jassim', phone: '+973 3333 8888', email: 'omar.jassim@301realestate.bh' }, images: ['family-apartment-with-balcony-sunny', 'living-room-apartment-comfortable', 'kitchen-apartment-modern-appliances', 'kids-bedroom-apartment', 'building-exterior-apartment-seef'], referenceId: '301-R-002' },
];
const initialCommercialProperties = [
  { id: 12, title: 'Prime Office Space in Diplomatic Area', price: 3000, leaseType: 'For Lease', type: 'Office', area: 450, location: 'Diplomatic Area, Manama', currency: 'BHD', category: 'commercial', description: 'Premium office space in a prestigious tower in the Diplomatic Area. Features partitioned offices, meeting rooms, and stunning sea views. Suitable for embassies, financial institutions, and multinational companies.', amenities: ['Partitioned Offices', 'Meeting Rooms', 'Sea Views', 'High-Speed Elevators', 'Basement Parking'], agent: { name: 'Ahmed Al Khalifa', phone: '+973 3333 9999', email: 'ahmed.khalifa@301realestate.bh' }, images: ['prime-office-space-downtown-lobby', 'office-reception-area-modern', 'meeting-room-large-table-projector', 'executive-office-sea-view', 'office-building-exterior-diplomatic'], referenceId: '301-C-001' },
  { id: 13, title: 'Retail Storefront in Seef Mall', price: 450000, leaseType: 'For Sale', type: 'Retail', area: 230, location: 'Seef District, Manama', currency: 'BHD', category: 'commercial', description: 'High-traffic retail unit for sale inside Seef Mall. Excellent visibility and footfall. Suitable for various retail concepts. A rare investment opportunity in a prime commercial hub.', amenities: ['High Footfall Location', 'Mall Access', 'Central AC', 'Shop Front Display', 'Storage Area'], agent: { name: 'Noora Abdulla', phone: '+973 3333 1010', email: 'noora.abdulla@301realestate.bh' }, images: ['retail-storefront-busy-street', 'retail-interior-shelving-units', 'mall-corridor-high-traffic', 'shop-window-display-mannequins', 'seef-mall-exterior-evening'], referenceId: '301-C-002' },
];

const allProperties = [...initialBuyProperties, ...initialRentProperties, ...initialCommercialProperties];

const PropertyDetailPage = () => {
  const { id } = useParams();
  const [property, setProperty] = useState(null);

  useEffect(() => {
    const foundProperty = allProperties.find(p => p.id.toString() === id);
    setProperty(foundProperty);
  }, [id]);

  const formatPrice = (price, currency, leaseType = null) => {
    let formattedPrice = new Intl.NumberFormat('en-BH', { style: 'currency', currency: currency, minimumFractionDigits: 0 }).format(price);
    if (leaseType === 'For Lease') {
      formattedPrice += '/mo';
    }
    return formattedPrice;
  };

  if (!property) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
          <Alert variant="destructive" className="w-full max-w-md">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Property Not Found</AlertTitle>
            <AlertDescription>
              The property you are looking for does not exist or may have been removed.
              <Button asChild variant="link" className="mt-2">
                <Link to="/">Go back to Home</Link>
              </Button>
            </AlertDescription>
          </Alert>
        </motion.div>
      </div>
    );
  }

  const pageVariants = {
    initial: { opacity: 0, y: 20 },
    in: { opacity: 1, y: 0 },
    out: { opacity: 0, y: -20 },
  };

  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={{ type: 'tween', ease: 'anticipate', duration: 0.5 }}
      className="container mx-auto py-8 px-4"
    >
      <BreadcrumbsAndActions property={property} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <PropertyImageGallery images={property.images} title={property.title} />
          <PropertyHeader property={property} formatPrice={formatPrice} />
          <PropertyKeyDetails property={property} />
          <PropertyDescription description={property.description} />
          <PropertyAmenities amenities={property.amenities} />
          <PropertyLocationMap location={property.location} />
        </div>

        <div className="lg:col-span-1 space-y-8">
          <PropertyAgentCard agent={property.agent} propertyTitle={property.title} propertyRefId={property.referenceId} propertyId={property.id}/>
          <PropertyMortgageCalculator />
        </div>
      </div>
    </motion.div>
  );
};

export default PropertyDetailPage;
  