
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Search, MapPin, Home, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const featuredProperties = [
    { id: 1, title: 'Luxury Villa in Downtown', price: 1200000, type: 'Sale', beds: 4, baths: 3, area: 325, image: 'modern-villa-exterior', description: 'Stunning villa with city views and private pool.', currency: 'BHD', category: 'buy' },
    { id: 7, title: 'Cozy Apartment with Park View', price: 950, type: 'Rent', beds: 2, baths: 2, area: 110, image: 'apartment-living-room-modern', description: 'Bright and airy apartment overlooking a serene park.', currency: 'BHD', category: 'rent' },
    { id: 12, title: 'Spacious Commercial Space', price: 1800, type: 'Commercial', area: 465, image: 'modern-office-space-large-windows', description: 'Prime commercial location with high foot traffic.', currency: 'BHD', category: 'commercial', leaseType: 'For Lease' },
  ];

  const formatPrice = (price, currency, leaseTypeArg = null) => {
    let formattedPrice = new Intl.NumberFormat('en-BH', { style: 'currency', currency: currency, minimumFractionDigits: 0 }).format(price);
    if (leaseTypeArg === 'For Lease' || leaseTypeArg === 'Rent') {
      formattedPrice += '/mo';
    }
    return formattedPrice;
  };

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <motion.section
        className="relative rounded-xl overflow-hidden shadow-2xl"
        initial="hidden"
        animate="visible"
        variants={fadeIn}
      >
        <div className="absolute inset-0">
          <img  class="w-full h-full object-cover" alt="Modern cityscape with diverse architecture" src="https://images.unsplash.com/photo-1633094321833-f6360e2eb0b2" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent"></div>
        </div>
        <div className="relative container mx-auto px-6 py-24 md:py-32 lg:py-40 text-white">
          <motion.h1 
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 leading-tight"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Find Your Dream Property
          </motion.h1>
          <motion.p 
            className="text-lg md:text-xl mb-8 max-w-2xl"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Discover a wide range of properties for sale and rent in Bahrain. Your next home or investment is just a click away.
          </motion.p>
          <motion.div 
            className="bg-white/90 backdrop-blur-sm p-6 rounded-lg shadow-xl max-w-3xl"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              <div className="space-y-1">
                <label htmlFor="location" className="text-sm font-medium text-slate-700">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="location" placeholder="e.g. Seef, Saar, Amwaj" className="pl-10 text-slate-800" />
                </div>
              </div>
              <div className="space-y-1">
                <label htmlFor="propertyType" className="text-sm font-medium text-slate-700">Property Type</label>
                <div className="relative">
                  <Home className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <Input id="propertyType" placeholder="Apartment, Villa, Office" className="pl-10 text-slate-800" />
                </div>
              </div>
              <Button size="lg" className="w-full md:w-auto bg-primary hover:bg-primary/90 text-white col-span-1 md:col-auto">
                <Search className="mr-2 h-5 w-5" /> Search
              </Button>
            </div>
          </motion.div>
        </div>
      </motion.section>

      {/* Featured Properties Section */}
      <motion.section variants={fadeIn} initial="hidden" animate="visible">
        <h2 className="text-3xl font-bold text-center mb-4 text-slate-800">Featured Properties</h2>
        <p className="text-center text-slate-600 mb-10 max-w-xl mx-auto">
          Explore some of our handpicked properties that offer exceptional value and quality.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProperties.map((property, index) => (
            <motion.div
              key={property.id}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={{
                hidden: { opacity: 0, y: 50 },
                visible: (i) => ({
                  opacity: 1,
                  y: 0,
                  transition: { delay: i * 0.15, duration: 0.5 }
                })
              }}
            >
              <Card className="overflow-hidden hover:shadow-2xl transition-shadow duration-300 h-full flex flex-col group">
                <div className="relative h-56">
                  <img  class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt={property.title} src="https://images.unsplash.com/photo-1675023112817-52b789fd2ef0" />
                  <div className="absolute top-2 right-2 bg-primary text-white px-3 py-1 rounded-full text-xs font-semibold">{property.type}</div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{property.title}</CardTitle>
                  <CardDescription className="text-sm text-slate-500">{property.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="flex items-center text-lg font-semibold text-primary mb-2">
                     {formatPrice(property.price, property.currency, property.leaseType || property.type)}
                  </div>
                  <div className="text-sm text-slate-600 space-y-1">
                    {property.beds && <p>Beds: {property.beds} | Baths: {property.baths} | Area: {property.area} m²</p>}
                    {!property.beds && <p>Area: {property.area} m²</p>}
                  </div>
                </CardContent>
                <div className="p-6 pt-0">
                  <Button asChild variant="outline" className="w-full group-hover:bg-primary group-hover:text-white transition-colors">
                    <Link to={`/property/${property.id}?category=${property.category}`}>
                      View Details <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
        <div className="text-center mt-12">
          <Button size="lg" asChild className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg transform hover:scale-105 transition-transform">
            <Link to="/buy">
              Explore All Properties <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </motion.section>

      {/* Call to Action Section */}
      <motion.section 
        className="bg-gradient-to-br from-slate-700 via-slate-800 to-black text-white py-20 rounded-xl shadow-xl"
        variants={fadeIn} initial="hidden" animate="visible"
      >
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Find Your Perfect Place?</h2>
          <p className="text-lg text-slate-300 mb-8 max-w-2xl mx-auto">
            Whether you're buying, selling, or renting, our expert agents are here to guide you every step of the way.
          </p>
          <div className="space-x-0 space-y-4 sm:space-y-0 sm:space-x-4">
            <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-slate-100 shadow-md transform hover:scale-105 transition-transform">
              Contact an Agent
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 shadow-md transform hover:scale-105 transition-transform">
              List Your Property
            </Button>
          </div>
        </div>
      </motion.section>
    </div>
  );
};

export default HomePage;
  