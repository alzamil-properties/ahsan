
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { MapPin, Bed, Bath, Maximize, Search, ArrowRight, Home } from 'lucide-react';
import { motion } from 'framer-motion';

const initialProperties = [
  { id: 7, title: 'Chic Studio in Adliya', price: 700, type: 'Studio', beds: 1, baths: 1, area: 55, location: 'Adliya, Manama', image: 'chic-studio-apartment-interior', currency: 'BHD', category: 'rent' },
  { id: 8, title: 'Family Apartment with Balcony Seef', price: 1000, type: 'Apartment', beds: 3, baths: 2, area: 140, location: 'Seef District, Manama', image: 'family-apartment-with-balcony-sunny', currency: 'BHD', category: 'rent' },
  { id: 9, title: 'Loft-Style Condo in Juffair', price: 850, type: 'Condo', beds: 2, baths: 1.5, area: 90, location: 'Juffair, Manama', image: 'loft-style-condo-brick-wall', currency: 'BHD', category: 'rent' },
  { id: 10, title: 'Furnished Townhouse in Riffa', price: 1300, type: 'Townhouse', beds: 3, baths: 2.5, area: 170, location: 'Riffa Views, Southern Governorate', image: 'furnished-townhouse-living-room', currency: 'BHD', category: 'rent' },
  { id: 11, title: 'Pet-Friendly Duplex in Saar', price: 950, type: 'Duplex', beds: 2, baths: 2, area: 120, location: 'Saar, Northern Governorate', image: 'pet-friendly-duplex-backyard', currency: 'BHD', category: 'rent' },
];

const RentPage = () => {
  const [properties, setProperties] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [propertyType, setPropertyType] = useState('all');
  const [priceRange, setPriceRange] = useState([0, 2000]); // Monthly rent
  const [bedrooms, setBedrooms] = useState('any');

  useEffect(() => {
    const storedProperties = JSON.parse(localStorage.getItem('properties_rent')) || initialProperties;
    setProperties(storedProperties);
    if (!localStorage.getItem('properties_rent')) {
      localStorage.setItem('properties_rent', JSON.stringify(initialProperties));
    }
  }, []);

  const filteredProperties = properties.filter(property => {
    return (
      (property.title.toLowerCase().includes(searchTerm.toLowerCase()) || property.location.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (propertyType === 'all' || property.type.toLowerCase() === propertyType.toLowerCase()) &&
      (property.price >= priceRange[0] && property.price <= priceRange[1]) &&
      (bedrooms === 'any' || property.beds >= parseInt(bedrooms))
    );
  });

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-BH', { style: 'currency', currency: 'BHD', minimumFractionDigits: 0 }).format(price) + "/mo";
  };
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.div initial="hidden" animate="visible" variants={fadeIn}>
        <h1 className="text-4xl font-bold mb-8 text-center text-slate-800">Properties for Rent</h1>
      </motion.div>

      <motion.div 
        className="mb-10 p-6 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl shadow-lg border border-slate-200"
        initial="hidden" animate="visible" variants={{...fadeIn, visible: {...fadeIn.visible, transition: {...fadeIn.visible.transition, delay: 0.2}}}}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
              <Input 
                placeholder="Keyword, Location..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Property Type</label>
            <Select value={propertyType} onValueChange={setPropertyType}>
              <SelectTrigger>
                <SelectValue placeholder="Select Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="studio">Studio</SelectItem>
                <SelectItem value="apartment">Apartment</SelectItem>
                <SelectItem value="condo">Condo</SelectItem>
                <SelectItem value="townhouse">Townhouse</SelectItem>
                <SelectItem value="duplex">Duplex</SelectItem>
                <SelectItem value="villa">Villa</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Bedrooms</label>
            <Select value={bedrooms} onValueChange={setBedrooms}>
              <SelectTrigger>
                <SelectValue placeholder="Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any</SelectItem>
                <SelectItem value="1">1+</SelectItem>
                <SelectItem value="2">2+</SelectItem>
                <SelectItem value="3">3+</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">
              Monthly Rent: {formatPrice(priceRange[0])} - {formatPrice(priceRange[1])}
            </label>
            <Slider
              value={priceRange}
              min={0}
              max={2000}
              step={50}
              onValueChange={setPriceRange}
              className="py-2"
            />
          </div>
           <Button className="lg:col-start-4 bg-primary hover:bg-primary/90 text-white">
            Apply Filters
          </Button>
        </div>
      </motion.div>

      {filteredProperties.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProperties.map((property, index) => (
            <motion.div
              key={property.id}
              custom={index}
              initial="hidden"
              animate="visible"
              variants={{
                hidden: { opacity: 0, y: 50 },
                visible: (i) => ({
                  opacity: 1,
                  y: 0,
                  transition: { delay: i * 0.1 + 0.4, duration: 0.5 }
                })
              }}
            >
              <Card className="overflow-hidden hover:shadow-2xl transition-shadow duration-300 h-full flex flex-col group">
                <div className="relative h-64">
                  <img  class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt={property.title} src="https://images.unsplash.com/photo-1685279053124-f47a436a9c1e" />
                  <div className="absolute top-3 left-3 bg-primary/80 backdrop-blur-sm text-white px-3 py-1.5 rounded-md text-xs font-semibold shadow-md">{property.type}</div>
                </div>
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">{property.title}</CardTitle>
                  <CardDescription className="flex items-center text-sm text-slate-500 pt-1">
                    <MapPin className="h-4 w-4 mr-1.5 flex-shrink-0" /> {property.location}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow space-y-3">
                  <div className="text-2xl font-bold text-primary flex items-center">
                     <Home className="h-6 w-6 mr-1.5" /> {formatPrice(property.price)}
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-slate-600">
                    <span className="flex items-center"><Bed className="h-4 w-4 mr-1.5 text-primary/70" /> {property.beds} Beds</span>
                    <span className="flex items-center"><Bath className="h-4 w-4 mr-1.5 text-primary/70" /> {property.baths} Baths</span>
                    <span className="flex items-center"><Maximize className="h-4 w-4 mr-1.5 text-primary/70" /> {property.area} m²</span>
                  </div>
                </CardContent>
                <div className="p-6 pt-0">
                   <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-white transition-colors" asChild>
                    <Link to={`/property/${property.id}?category=${property.category}`}>
                      View Details <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
         <motion.div 
          className="text-center py-12"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        >
          <Search className="h-16 w-16 mx-auto text-slate-400 mb-4" />
          <p className="text-xl text-slate-600">No rental properties match your current filters.</p>
          <p className="text-slate-500">Try adjusting your search criteria.</p>
        </motion.div>
      )}
    </div>
  );
};

export default RentPage;
  