
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Layout from '@/components/Layout';
import DashboardLayout from '@/components/DashboardLayout';
import HomePage from '@/pages/HomePage';
import BuyPage from '@/pages/BuyPage';
import RentPage from '@/pages/RentPage';
import CommercialPage from '@/pages/CommercialPage';
import PropertyDetailPage from '@/pages/PropertyDetailPage';
import DashboardPage from '@/pages/DashboardPage';
import AddPropertyPage from '@/pages/AddPropertyPage';
import NotFoundPage from '@/pages/NotFoundPage';

// Mock authentication check
const isAuthenticated = () => {
  // In a real app, this would check a token or session
  // For now, let's assume the agent is always "logged in" for dashboard access
  // Or, you could use a simple localStorage flag
  return true; 
};

const ProtectedRoute = ({ children }) => {
  if (!isAuthenticated()) {
    return <Navigate to="/" replace />;
  }
  return children;
};

function App() {
  return (
    <Router>
      <Toaster />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="buy" element={<BuyPage />} />
          <Route path="rent" element={<RentPage />} />
          <Route path="commercial" element={<CommercialPage />} />
          <Route path="property/:id" element={<PropertyDetailPage />} />
        </Route>
        
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<DashboardPage />} />
          <Route path="add-property" element={<AddPropertyPage />} />
          {/* Add more dashboard routes here, e.g., edit-property/:id */}
        </Route>

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Router>
  );
}

export default App;
  